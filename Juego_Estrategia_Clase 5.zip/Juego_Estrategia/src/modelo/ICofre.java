package modelo;

public interface ICofre
{
void hechizar(Hechizable hechizable );
	

}
