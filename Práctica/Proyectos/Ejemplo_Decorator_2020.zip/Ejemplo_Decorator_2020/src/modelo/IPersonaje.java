package modelo;

public interface IPersonaje
{
double getArmadura();
double getAtaqueCorto();
double getAtaqueDistante();
String getNombre();


}
