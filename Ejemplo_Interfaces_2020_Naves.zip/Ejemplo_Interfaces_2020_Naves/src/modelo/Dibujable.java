package modelo;

public interface Dibujable
{
void dibujar();
}
