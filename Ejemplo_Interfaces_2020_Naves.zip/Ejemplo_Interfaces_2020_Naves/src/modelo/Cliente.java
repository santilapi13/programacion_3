package modelo;

public class Cliente
{

	public void metodoQueMueve(Movible movible)
	{
		movible.mueve(5, 17);
		
		
	}
	
	
	public void metodoQueDibuja(Dibujable dibujable)
	{
		dibujable.dibujar();
		
		
	}
	
	
}
