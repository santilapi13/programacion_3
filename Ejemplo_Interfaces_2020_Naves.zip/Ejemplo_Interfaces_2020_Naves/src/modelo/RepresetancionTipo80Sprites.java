package modelo;

public class RepresetancionTipo80Sprites implements Dibujable
{

	

	@Override
	public void dibujar()
	{
		// Supongamos que tenemos cientos
				// de lineas de codigo
				// muy complicado
				System.out.println("Aqui se realizar�a un algoritmo de dibujado en 2D utilizando SPRITES y paralax");

	}

}
