package modelo;

public interface Hechizable
{
void serBendecido();
void serMaldecido();
}
