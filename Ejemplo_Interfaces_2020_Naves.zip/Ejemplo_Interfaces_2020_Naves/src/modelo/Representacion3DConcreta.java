package modelo;

public class Representacion3DConcreta implements Dibujable
{

	@Override
	public void dibujar()
	{
		// Supongamos que tenemos cientos
		// de lineas de codigo
		// muy complicado
		System.out.println("Aqui se realizar�a un algoritmo de dibujado 3D muy complejo");
	}
		
	}


